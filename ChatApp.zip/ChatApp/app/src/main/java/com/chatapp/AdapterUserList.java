package com.chatapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import de.hdodenhof.circleimageview.CircleImageView;

public class AdapterUserList extends RecyclerView.Adapter<AdapterUserList.Holder> {
    LayoutInflater layoutInflater;
    Activity activity;
    ArrayList<PojoUser> al_user;
    public AdapterUserList(Activity activity, ArrayList<PojoUser> al_user) {
        this.activity=activity;
        this.al_user=al_user;
        layoutInflater=LayoutInflater.from(activity);
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = layoutInflater.inflate(R.layout.design_user, viewGroup, false);
        Holder vh = new Holder(itemView);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull final Holder holder, int i) {
        final PojoUser pojoUser=al_user.get(i);
holder.tvName.setText(pojoUser.getName());

if (pojoUser.getLastMsg().contains("https")){
    holder.tvLastMsg.setText(pojoUser.getSenderName()+" ");
    holder.ivImage.setVisibility(View.VISIBLE);

}else {
    holder.ivImage.setVisibility(View.GONE);
    holder.tvLastMsg.setText(pojoUser.getSenderName()+" : "+pojoUser.getLastMsg());
}


        holder.tvDate.setText(pojoUser.getDate());
        Glide.with(activity)
                .load(pojoUser.getImage())
                .centerCrop()
                .placeholder(R.drawable.user)
                .into(holder.circleImageView);
        holder.llLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserDetails.chatWith = pojoUser.getName();
                UserDetails.partnerId = pojoUser.getUserId();
                activity.startService(new Intent(activity, ServiceChat.class));

                activity.startActivity(new Intent(activity, ChatActivity.class));




            }
        });
    }

    @Override
    public int getItemCount() {
        return al_user.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView tvName,tvLastMsg,tvDate;
        CircleImageView circleImageView;
        LinearLayout llLayout;
        ImageView ivImage;
        public Holder(@NonNull View itemView) {
            super(itemView);
            tvName=itemView.findViewById(R.id.tvName);
            tvLastMsg=itemView.findViewById(R.id.tvLastMsg);
            tvDate=itemView.findViewById(R.id.tvDate);
            circleImageView=itemView.findViewById(R.id.cvImage);
            ivImage=itemView.findViewById(R.id.ivImage);
            llLayout=itemView.findViewById(R.id.llLayout);
        }
    }
}

package com.chatapp;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.firebase.client.ChildEventListener;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

import java.util.Map;

public class ServiceChat extends Service {
    Firebase reference1;



    public ServiceChat() {
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {



        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.e(">>>","startService");
        Firebase.setAndroidContext(getApplicationContext());
        reference1 = new Firebase("https://chatapp-9dacf.firebaseio.com/messages/" + UserDetails.username + "_" + UserDetails.chatWith);


        reference1.addChildEventListener(new ChildEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {




            }
            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                Map map = dataSnapshot.getValue(Map.class);
                dataSnapshot.getChildren();
                dataSnapshot.getKey();
                String time=map.get("time").toString();
                String message = map.get("message").toString();
                String userName = map.get("user").toString();
                String Image = map.get("image").toString();
                String s_image = map.get("s_image").toString();
                String forward_count = map.get("forward_count").toString();
                String forward_mes= map.get("forward_mes").toString();

                PojoChat pojoChat = new PojoChat();
                pojoChat.setMessage(message);
                pojoChat.setTime(time);
                pojoChat.setForward_mes(forward_mes);
                pojoChat.setS_image(s_image);
                pojoChat.setKey(dataSnapshot.getKey());
                pojoChat.setF_count(forward_count);
                pojoChat.setImage(Image);
                if (userName.equals(UserDetails.username)) {
                    pojoChat.setUserName("You");
                } else {
                    addNotification(message,userName);
                }
            }
            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }
            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }
            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
        return START_STICKY;
    }

    private void addNotification(String msg,String userName) {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.ic_image_black_24dp)
                        .setContentTitle("New Message")
                        .setContentText(userName+" " +msg);

        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(contentIntent);

        // Add as notification
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(0, builder.build());
    }
}


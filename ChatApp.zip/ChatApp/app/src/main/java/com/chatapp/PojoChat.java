package com.chatapp;

public class PojoChat {


    String forward_mes,key,userName,message,image,s_image,f_count,time;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getKey() {
        return key;
    }

    public String getForward_mes() {
        return forward_mes;
    }

    public void setForward_mes(String forward_mes) {
        this.forward_mes = forward_mes;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getS_image() {
        return s_image;
    }

    public String getF_count() {
        return f_count;
    }

    public void setF_count(String f_count) {
        this.f_count = f_count;
    }

    public void setS_image(String s_image) {
        this.s_image = s_image;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}

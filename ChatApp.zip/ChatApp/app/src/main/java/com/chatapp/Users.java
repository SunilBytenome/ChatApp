package com.chatapp;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

public class Users extends AppCompatActivity {
    RecyclerView usersList;
    TextView noUsersText;
    ArrayList<String> al = new ArrayList<>();
    int totalUsers = 0;
    ProgressDialog pd;
    ArrayList<PojoUser> al_user=new ArrayList<>();
    private LinearLayoutManager manager;
    AdapterUserList adapterUserList;
    private ImageView ivBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);
        usersList = (RecyclerView)findViewById(R.id.usersList);
        noUsersText = (TextView)findViewById(R.id.noUsersText);
        ivBack=(ImageView) findViewById(R.id.ivBack);

        clicks();
    }

    private void clicks() {
       ivBack.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               finish();
           }
       });
    }

    @Override
    protected void onResume() {
        pd = new ProgressDialog(Users.this);
        pd.setMessage("Loading...");
        pd.show();

        String url = "https://chatapp-9dacf.firebaseio.com/user.json";

        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>(){
            @Override
            public void onResponse(String s) {
                doOnSuccess(s);
            }
        },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                System.out.println("" + volleyError);
            }
        });

        RequestQueue rQueue = Volley.newRequestQueue(Users.this);
        rQueue.add(request);
        super.onResume();
    }

    public void doOnSuccess(String s){
        al_user.clear();
        try {
            JSONObject obj = new JSONObject(s);

            Iterator i = obj.keys();
            String key = "";

            while(i.hasNext()){
                key = i.next().toString();

                if(!key.equals(UserDetails.username)) {
                    String image="",date="",lastMsg="",senderName="";

                    String name=  obj.getJSONObject(key).getJSONObject("Detail").getString("name");
                    String userId=  obj.getJSONObject(key).getJSONObject("Detail").getString("userId");

                    try{
                        image=  obj.getJSONObject(key).getJSONObject("Detail").getString("image");
                        date=  obj.getJSONObject(key).getJSONObject("Detail").getString("date");
                        lastMsg=  obj.getJSONObject(key).getJSONObject("Detail").getString("lastMsg");
                        senderName=  obj.getJSONObject(key).getJSONObject("Detail").getString("senderName");
                    }catch (Exception e)
                    { }
                    try{
                        image=  obj.getJSONObject(key).getJSONObject("Detail").getString("image");
                        date=  obj.getJSONObject(key).getJSONObject("Detail").getString("date");
                        lastMsg=  obj.getJSONObject(key).getJSONObject("Detail").getString("lastMsg");
                        senderName=  obj.getJSONObject(key).getJSONObject("Detail").getString("senderName");
                    }catch (Exception e)
                    { }
                    try{
                        image=  obj.getJSONObject(key).getJSONObject("Detail").getString("image");
                        date=  obj.getJSONObject(key).getJSONObject("Detail").getString("date");
                        lastMsg=  obj.getJSONObject(key).getJSONObject("Detail").getString("lastMsg");
                        senderName=  obj.getJSONObject(key).getJSONObject("Detail").getString("senderName");
                    }catch (Exception e)
                    { }
                    try{
                        image=  obj.getJSONObject(key).getJSONObject("Detail").getString("image");
                        date=  obj.getJSONObject(key).getJSONObject("Detail").getString("date");
                        lastMsg=  obj.getJSONObject(key).getJSONObject("Detail").getString("lastMsg");
                        senderName=  obj.getJSONObject(key).getJSONObject("Detail").getString("senderName");
                    }catch (Exception e)
                    { }
                    PojoUser pojoUser=new PojoUser(senderName,name,"","",userId,image,lastMsg,date);
                    al_user.add(pojoUser);

                    al.add(key);
                }

                totalUsers++;
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if(totalUsers <=1){
            noUsersText.setVisibility(View.VISIBLE);
            usersList.setVisibility(View.GONE);
        }
        else{
            noUsersText.setVisibility(View.GONE);
            usersList.setVisibility(View.VISIBLE);
            adapterUserList=new AdapterUserList(Users.this,al_user);
            manager = new LinearLayoutManager(Users.this);
            usersList.setLayoutManager(manager);
            usersList.setAdapter(adapterUserList);

          //  usersList.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, al));
        }

        pd.dismiss();
    }
}

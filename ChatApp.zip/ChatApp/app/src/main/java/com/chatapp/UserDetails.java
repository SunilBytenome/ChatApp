package com.chatapp;

/**
 * Created by Bytenome-01 on 6/14/2017.
 */

public class UserDetails {

        static String userId = "";
        static String partnerId = "";
        static String username = "";
        static String password = "";
        static String chatWith = "";
        static String userUpdateMsg="https://chatapp-9dacf.firebaseio.com/user/";



}
